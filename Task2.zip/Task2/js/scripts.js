$(document).ready(function(){		
			var count=1;
			var color=1;
			$("button").click(function(){
				var clr=$("#code").val();
				var shape=$("#shapes").val();
					if(shape === "Circle")
					{
						var fig1="<div class='cirfig' id="+count+" ><input type='text' class='color1' id="+color+"></div><br>";
						$(".cir").append(fig1);
						$(".cir .cirfig:last").css("background-color",clr);
						
						var hex = $("#"+count).css('background-color');
					    	if(getBrightness(hex) < 50){
					        	$('#'+color).css('color','#FFFFFF');
					    } else {
					        	$('#'+color).css('color','#000000');
					    }	
					    
                        
					    $(".color1").val(clr);	
						count++;
						color++;
					}				

	});

			$("button").click(function(){
				var clr=$("#code").val();
				var shape=$("#shapes").val();
					if(shape === "Rectangle")
					{
						var fig1="<div class='rectfig' id="+count+"><input type='text' class='color2'></div><br>";
						$(".rect").append(fig1);
						$(".rect .rectfig:last").css("background-color",clr);
						var hex = $(".rectfig").css('background-color');
					    	if(getBrightness(hex) < 50){
					        	$('.color2').css('color','#FFFFFF');
					    } else {
					        	$('.color2').css('color','#000000');
					    }	
						$(".color2").val(clr);
						count++;
					}
				
	});

			$("button").click(function(){
				var shape=$("#shapes").val();
				var clr=$("#code").val();
				if(shape === "Square")
				{
					var fig1="<div class='squarefig' id="+count+"><input type='text' class='color3'></div><br>";
					$(".square").append(fig1);
					$(".square .squarefig:last").css("background-color",clr);
					var hex = $(".squarefig").css('background-color');
					    	if(getBrightness(hex) < 50){
					        	$('.color3').css('color','#FFFFFF');
					    } else {
					        	$('.color3').css('color','#000000');
					    }	
					$(".color3").val(clr);
					count++;
				
				}
				
	});
			$("#col2").on('keyup', ':input', function(){
						var s=$(this).parent().attr("id");
						var change=$(this).val();
						$("#"+s).css("background-color",change);
						var hex = $("#"+s).css('background-color');
					    	if(getBrightness(hex) < 50){
					        $('.color2').css('color','#FFFFFF');
					    } else {
					        $('.color2').css('color','#000000');
					    }	
					});

			$("#col3").on('keyup', ':input', function(){
						var s=$(this).parent().attr("id");
						var change=$(this).val();
						$("#"+s).css("background-color",change);
						var hex = $("#"+s).css('background-color');
					    	if(getBrightness(hex) < 50){
					        $('.color3').css('color','#FFFFFF');
					    } else {
					        $('.color3').css('color','#000000');
					    }	
					});

			$("#col1").on('keyup', ':input', function(){
						var s=$(this).parent().attr("id");
						var change=$(this).val();
						$("#"+s).css("background-color",change);
						var hex = $("#"+s).css('background-color');
					    	if(getBrightness(hex) < 50){
					        $('.color1').css('color','#FFFFFF');
					    } else {
					        $('.color1').css('color','#000000');
					    }		
					});

 
function getBrightness(hex) {
    var rgb = hex.replace(/^(rgb|rgba)\(/,'').replace(/\)$/,'').replace(/\s/g,'').split(',');


	var c_r=rgb[0];
    var c_g=rgb[1];
    var c_b=rgb[2];
 
    
    return ((c_r * 299) + (c_g * 587) + (c_b * 114)) / 1000;
}
 
  });
  

